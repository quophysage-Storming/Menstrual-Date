
package com.my.menstradate.sagemadeit;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class CustomSheetFragment extends BottomSheetDialogFragment {

    private static final String FONT_PATH = "fonts/ooo.ttf";

    private static final String COLOR_BG = "#FFFFFF";
    private static final String COLOR_SURFACE = "#F5F5F5";
    private static final String COLOR_RIPPLE = "#3340A8F6";

    private static final float SHEET_RADIUS = 28f;
    private static final float CONTENT_RADIUS = 24f;
    private static final float ROW_RADIUS = 18f;
    private static final float HANDLE_RADIUS = 50f;

    private LinearLayout linear1;
    private LinearLayout linear9;
    private LinearLayout googleRow;
    private LinearLayout whatsappRow;

    private TextView textview1;
    private TextView text_next;

    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth firebaseAuth;
    private SharedPreferences sp;

    private final ActivityResultLauncher<Intent> googleSignInLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    this::handleGoogleSignInResult
            );

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Use the same SharedPreferences file name: sp
        sp = requireActivity().getSharedPreferences(
                "sp",
                Context.MODE_PRIVATE
        );

        firebaseAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions options =
                new GoogleSignInOptions.Builder(
                        GoogleSignInOptions.DEFAULT_SIGN_IN
                )
                        .requestIdToken(
                                getString(R.string.default_web_client_id)
                        )
                        .requestEmail()
                        .build();

        googleSignInClient = GoogleSignIn.getClient(
                requireActivity(),
                options
        );
    }

    private void startGoogleSignIn() {
        if (!isAdded() || googleSignInClient == null) {
            return;
        }

        googleSignInLauncher.launch(
                googleSignInClient.getSignInIntent()
        );
    }

    private void handleGoogleSignInResult(ActivityResult result) {

        if (result.getResultCode() != android.app.Activity.RESULT_OK
                || result.getData() == null) {

            if (isAdded()) {
                Toast.makeText(
                        requireContext(),
                        "Google sign-in cancelled",
                        Toast.LENGTH_SHORT
                ).show();
            }
            return;
        }

        Task<GoogleSignInAccount> task =
                GoogleSignIn.getSignedInAccountFromIntent(
                        result.getData()
                );

        try {
            GoogleSignInAccount account =
                    task.getResult(ApiException.class);

            if (account == null || account.getIdToken() == null) {
                Toast.makeText(
                        requireContext(),
                        "Google sign-in failed: missing ID token",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            AuthCredential credential =
                    GoogleAuthProvider.getCredential(
                            account.getIdToken(),
                            null
                    );

            firebaseAuth.signInWithCredential(credential)
                    .addOnCompleteListener(requireActivity(), authTask -> {

                        if (!isAdded()) {
                            return;
                        }

                        if (authTask.isSuccessful()) {

                            FirebaseUser user =
                                    firebaseAuth.getCurrentUser();

                            if (user == null) {
                                Toast.makeText(
                                        requireContext(),
                                        "Could not load user information",
                                        Toast.LENGTH_SHORT
                                ).show();
                                return;
                            }

                            String username = user.getDisplayName();
                            String profile = "";

                            if (username == null
                                    || username.trim().isEmpty()) {
                                username = "User";
                            }

                            if (user.getPhotoUrl() != null) {
                                profile = user.getPhotoUrl().toString();
                            }

                            // Save profile details for SecondActivity.
                            sp.edit()
                                    .putString("username", username)
                                    .putString("profile", profile)
                                    .apply();

                            Toast.makeText(
                                    requireContext(),
                                    "Welcome, " + username,
                                    Toast.LENGTH_SHORT
                            ).show();

                            // Open SecondActivity after successful login.
                            Intent intent = new Intent(
                                    requireActivity(),
                                    SecondActivity.class
                            );

                            startActivity(intent);

                            // Close the bottom sheet.
                            dismiss();

                        } else {

                            String message =
                                    authTask.getException() != null
                                            ? authTask.getException().getMessage()
                                            : "Unknown authentication error";

                            Toast.makeText(
                                    requireContext(),
                                    "Firebase sign-in failed: " + message,
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    });

        } catch (ApiException e) {

            if (isAdded()) {
                Toast.makeText(
                        requireContext(),
                        "Google sign-in failed: " + e.getStatusCode(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(
            @Nullable Bundle savedInstanceState) {

        return new BottomSheetDialog(requireContext());
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.custom_bottom_sheet,
                container,
                false
        );

        linear1 = view.findViewById(R.id.linear1);
        linear9 = view.findViewById(R.id.linear9);

        googleRow = view.findViewById(R.id.linear_google);
        whatsappRow = view.findViewById(R.id.linear_whatsapp);

        textview1 = view.findViewById(R.id.textview1);
        text_next = view.findViewById(R.id.text_next);

        if (linear1 == null
                || linear9 == null
                || googleRow == null
                || whatsappRow == null
                || textview1 == null
                || text_next == null) {
            return view;
        }

        // Main white content container.
        linear1.setBackground(
                roundedBackground(COLOR_BG, CONTENT_RADIUS)
        );
        linear1.setClipToOutline(true);

        // Rounded handle.
        linear9.setBackground(
                roundedBackground(COLOR_SURFACE, HANDLE_RADIUS)
        );
        linear9.setClipToOutline(true);

        // Style the Google and WhatsApp rows.
        styleConnectionRow(googleRow);
        styleConnectionRow(whatsappRow);

        // Preserve the original font styling.
        applyFontRecursively(view);

        googleRow.setOnClickListener(v -> startGoogleSignIn());

        whatsappRow.setOnClickListener(v -> {
            if (isAdded()) {
                Toast.makeText(
                        requireContext(),
                        "Update on your cycle will be sent to your phone daily...",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        return view;
    }

    private void styleConnectionRow(LinearLayout row) {
        if (row == null) {
            return;
        }

        GradientDrawable background =
                roundedBackground(COLOR_SURFACE, ROW_RADIUS);

        GradientDrawable mask =
                roundedBackground(Color.WHITE, ROW_RADIUS);

        Drawable ripple = new RippleDrawable(
                ColorStateList.valueOf(
                        Color.parseColor(COLOR_RIPPLE)
                ),
                background,
                mask
        );

        row.setBackground(ripple);
        row.setClipToOutline(true);
        row.setClickable(true);
        row.setFocusable(true);
    }

    private GradientDrawable roundedBackground(
            String color,
            float radiusDp) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(dp(radiusDp));

        return drawable;
    }

    private GradientDrawable roundedBackground(
            int color,
            float radiusDp) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));

        return drawable;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Pause MainActivity auto-navigation while the sheet is open.
        if (getActivity() instanceof MainActivity) {
            MainActivity activity = (MainActivity) getActivity();

            if (activity.handler != null
                    && activity.runnable != null) {
                activity.handler.removeCallbacks(
                        activity.runnable
                );
            }
        }

        Dialog currentDialog = getDialog();

        if (currentDialog instanceof BottomSheetDialog) {

            BottomSheetDialog dialog =
                    (BottomSheetDialog) currentDialog;

            Window window = dialog.getWindow();

            if (window != null) {
                window.setBackgroundDrawableResource(
                        android.R.color.transparent
                );

                window.addFlags(
                        WindowManager.LayoutParams.FLAG_DIM_BEHIND
                );
            }

            View bottomSheet = dialog.findViewById(
                    com.google.android.material.R.id.design_bottom_sheet
            );

            if (bottomSheet != null) {

                GradientDrawable sheetBackground =
                        new GradientDrawable();

                sheetBackground.setColor(
                        Color.parseColor(COLOR_BG)
                );

                float radius = dp(SHEET_RADIUS);

                sheetBackground.setCornerRadii(new float[]{
                        radius, radius,
                        radius, radius,
                        0f, 0f,
                        0f, 0f
                });

                bottomSheet.setBackground(sheetBackground);
                bottomSheet.setClipToOutline(true);

                BottomSheetBehavior<View> behavior =
                        BottomSheetBehavior.from(bottomSheet);

                behavior.setState(
                        BottomSheetBehavior.STATE_EXPANDED
                );

                behavior.setSkipCollapsed(true);
            }
        }
    }

    @Override
    public void onDismiss(
            @NonNull DialogInterface dialog) {

        super.onDismiss(dialog);

        // Resume MainActivity auto-navigation after 4 seconds.
        if (getActivity() instanceof MainActivity) {

            MainActivity activity = (MainActivity) getActivity();

            if (activity.handler != null
                    && activity.runnable != null) {
                activity.handler.postDelayed(
                        activity.runnable,
                        4000
                );
            }
        }
    }

    private float dp(float value) {
        return value * requireContext()
                .getResources()
                .getDisplayMetrics()
                .density;
    }

    private void applyFontRecursively(View view) {
        try {
            Typeface typeface = Typeface.createFromAsset(
                    requireContext().getAssets(),
                    FONT_PATH
            );

            applyFontToView(view, typeface);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void applyFontToView(
            View view,
            Typeface typeface) {

        if (view instanceof TextView) {
            ((TextView) view).setTypeface(typeface);
        }

        if (view instanceof ViewGroup) {

            ViewGroup group = (ViewGroup) view;

            for (int i = 0; i < group.getChildCount(); i++) {
                applyFontToView(
                        group.getChildAt(i),
                        typeface
                );
            }
        }
    }
}