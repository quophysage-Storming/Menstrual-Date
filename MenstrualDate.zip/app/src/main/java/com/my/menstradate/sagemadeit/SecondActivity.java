package com.my.menstradate.sagemadeit;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SecondActivity extends AppCompatActivity {
	
	public final int REQ_CD_GLOGINAUTH = 101;
	
	FirebaseUser user;
	GoogleSignInOptions gso;
	
	private FrameLayout frame_layout17;
	private ScrollView vscroll3;
	private LinearLayout linear19;
	private LinearLayout linear29;
	private TextView textview23;
	private LinearLayout linear30;
	private TextView textview24;
	private TextView textview25;
	private LinearLayout linear32;
	private LinearLayout linear20;
	private TextView textview27;
	private LinearLayout linear21;
	private TextView textview32;
	private LinearLayout view1;
	private TextView textview33;
	private AdView adview1;
	private TextView textview26;
	private LinearLayout linear33;
	private TextView txtCycleDay;
	private TextView txtCycleStatus;
	private TextView txtNextPeriod;
	private CircleImageView imageview1;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private TextView textview28;
	private TextView textview29;
	private TextView txtOvulation;
	private TextView textview30;
	private TextView textview31;
	private TextView txtFertileWindow;
	private LinearLayout linear11;
	private LinearLayout linear4;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private ImageView imageview4;
	private TextView textview5;
	
	private GoogleSignInClient gloginAuth;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		EdgeToEdge.enable(this);
		setContentView(R.layout.second);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		// It is causing a noticeable decrease in performance! We recommend you do this in the Application instead here if you know how.
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		frame_layout17 = findViewById(R.id.frame_layout17);
		vscroll3 = findViewById(R.id.vscroll3);
		linear19 = findViewById(R.id.linear19);
		linear29 = findViewById(R.id.linear29);
		textview23 = findViewById(R.id.textview23);
		linear30 = findViewById(R.id.linear30);
		textview24 = findViewById(R.id.textview24);
		textview25 = findViewById(R.id.textview25);
		linear32 = findViewById(R.id.linear32);
		linear20 = findViewById(R.id.linear20);
		textview27 = findViewById(R.id.textview27);
		linear21 = findViewById(R.id.linear21);
		textview32 = findViewById(R.id.textview32);
		view1 = findViewById(R.id.view1);
		textview33 = findViewById(R.id.textview33);
		adview1 = findViewById(R.id.adview1);
		textview26 = findViewById(R.id.textview26);
		linear33 = findViewById(R.id.linear33);
		txtCycleDay = findViewById(R.id.txtCycleDay);
		txtCycleStatus = findViewById(R.id.txtCycleStatus);
		txtNextPeriod = findViewById(R.id.txtNextPeriod);
		imageview1 = findViewById(R.id.imageview1);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		textview28 = findViewById(R.id.textview28);
		textview29 = findViewById(R.id.textview29);
		txtOvulation = findViewById(R.id.txtOvulation);
		textview30 = findViewById(R.id.textview30);
		textview31 = findViewById(R.id.textview31);
		txtFertileWindow = findViewById(R.id.txtFertileWindow);
		linear11 = findViewById(R.id.linear11);
		linear4 = findViewById(R.id.linear4);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		imageview2 = findViewById(R.id.imageview2);
		textview3 = findViewById(R.id.textview3);
		imageview3 = findViewById(R.id.imageview3);
		textview4 = findViewById(R.id.textview4);
		imageview4 = findViewById(R.id.imageview4);
		textview5 = findViewById(R.id.textview5);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		textview32.setOnClickListener(_v -> _showMyBottomSheet());
		
		linear13.setOnClickListener(_v -> {
			// Inflate the custom layout
			android.view.View settings = getLayoutInflater()
			.inflate(R.layout.settings, null);
			
			// Dialog background with rounded corners
			android.graphics.drawable.GradientDrawable roundedBackground =
			new android.graphics.drawable.GradientDrawable();
			
			roundedBackground.setColor(
			android.graphics.Color.parseColor("#FFFFFF")
			);
			
			float radius = 24 * getResources()
			.getDisplayMetrics().density;
			
			roundedBackground.setCornerRadius(radius);
			
			// Apply background and clipping to the custom layout
			settings.setBackground(roundedBackground);
			settings.setClipToOutline(true);
			
			// Density for dimensions
			float density = getResources()
			.getDisplayMetrics().density;
			
			// Helper method to create rounded ripple backgrounds
			java.util.function.BiFunction<Integer, Float,
			android.graphics.drawable.Drawable> createRipple =
			(backgroundColor, cornerRadius) -> {
				
				android.graphics.drawable.GradientDrawable shape =
				new android.graphics.drawable.GradientDrawable();
				
				shape.setColor(backgroundColor);
				shape.setCornerRadius(cornerRadius);
				
				android.graphics.drawable.GradientDrawable mask =
				new android.graphics.drawable.GradientDrawable();
				
				mask.setColor(android.graphics.Color.WHITE);
				mask.setCornerRadius(cornerRadius);
				
				android.graphics.drawable.RippleDrawable ripple =
				new android.graphics.drawable.RippleDrawable(
				android.content.res.ColorStateList.valueOf(
				android.graphics.Color.parseColor("#26008DCD")
				),
				shape,
				mask
				);
				
				return ripple;
			};
			
			// Find views inside the settings custom layout
			android.widget.LinearLayout linear7 =
			settings.findViewById(R.id.linear7);
			
			android.widget.LinearLayout linear11 =
			settings.findViewById(R.id.linear11);
			
			android.widget.LinearLayout next_button =
			settings.findViewById(R.id.next_button);
			
			// Apply rounded corners and ripple to linear7
			if (linear7 != null) {
				linear7.setBackground(createRipple.apply(
				android.graphics.Color.parseColor("#F5F7FA"),
				16 * density
				));
				linear7.setClickable(true);
				linear7.setFocusable(true);
			}
			
			// Apply rounded corners and ripple to linear11
			if (linear11 != null) {
				linear11.setBackground(createRipple.apply(
				android.graphics.Color.parseColor("#F5F7FA"),
				16 * density
				));
				linear11.setClickable(true);
				linear11.setFocusable(true);
			}
			
			// Apply rounded corners and ripple to next_button
			if (next_button != null) {
				next_button.setBackground(createRipple.apply(
				android.graphics.Color.parseColor("#F5F7FA"),
				16 * density
				));
				
				next_button.setClickable(true);
				next_button.setFocusable(true);
			}
			
			// Create the dialog
			final android.app.AlertDialog dialog =
			new android.app.AlertDialog.Builder(SecondActivity.this)
			.setView(settings)
			.create();
			
			// Show the dialog
			dialog.show();
			
			// Style the dialog window
			android.view.Window window = dialog.getWindow();
			
			if (window != null) {
				
				// Transparent window background
				window.setBackgroundDrawable(
				new android.graphics.drawable.ColorDrawable(
				android.graphics.Color.TRANSPARENT
				)
				);
				
				// Dim background behind dialog
				window.addFlags(
				android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND
				);
				
				android.view.WindowManager.LayoutParams params =
				window.getAttributes();
				
				params.dimAmount = 0.5f;
				window.setAttributes(params);
				
				// Dialog width with side margins
				window.setLayout(
				(int) (getResources().getDisplayMetrics().widthPixels
				* 0.90f),
				android.view.WindowManager.LayoutParams.WRAP_CONTENT
				);
			}
		});
		
		auth_updateEmailListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_updatePasswordListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_emailVerificationSentListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_deleteUserListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_phoneAuthListener = task -> {
			final boolean _success = task.isSuccessful();
			final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
			
		};
		
		auth_updateProfileListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_googleSignInListener = task -> {
			final boolean _success = task.isSuccessful();
			final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
			
		};
		
		_auth_create_user_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		_auth_sign_in_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		_auth_reset_password_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			
		};
	}
	
	private void initializeLogic() {
		{
			AdRequest adRequest = new AdRequest.Builder().build();
			adview1.loadAd(adRequest);
		}
		textview24.setText(sp.getString("username", ""));
		Glide.with(getApplicationContext()).load(Uri.parse(sp.getString("profile", ""))).into(imageview1);
		getWindow().getDecorView().setSystemUiVisibility(
		android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
		| android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
		| android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
		| android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
		);
		View rootView = findViewById(android.R.id.content);
		rootView.setAlpha(0f);
		
		ObjectAnimator fadeIn = ObjectAnimator.ofFloat(rootView, "alpha", 1f);
		fadeIn.setDuration(250);
		fadeIn.start();
		
		final android.widget.FrameLayout frame =
		findViewById(R.id.frame_layout17);
		
		final android.widget.ScrollView scroll =
		findViewById(R.id.vscroll3);
		
		final android.widget.LinearLayout bottomNav =
		findViewById(R.id.view1);
		
		// Remove view1 from its current parent
		if (bottomNav.getParent() instanceof android.view.ViewGroup) {
			((android.view.ViewGroup) bottomNav.getParent())
			.removeView(bottomNav);
		}
		
		// Telegram-style compact floating pill
		android.widget.FrameLayout.LayoutParams navParams =
		new android.widget.FrameLayout.LayoutParams(
		(int) (320 * getResources()
		.getDisplayMetrics().density + 0.5f),
		(int) (72 * getResources()
		.getDisplayMetrics().density + 0.5f)
		);
		
		navParams.gravity = android.view.Gravity.BOTTOM
		| android.view.Gravity.CENTER_HORIZONTAL;
		
		navParams.bottomMargin = (int) (16 * getResources()
		.getDisplayMetrics().density + 0.5f);
		
		// Apply size and position
		bottomNav.setLayoutParams(navParams);
		
		// Rounded floating appearance
		android.graphics.drawable.GradientDrawable navBackground =
		new android.graphics.drawable.GradientDrawable();
		
		navBackground.setColor(android.graphics.Color.rgb(255, 249, 252));
		
		navBackground.setCornerRadius(
		36 * getResources().getDisplayMetrics().density
		);
		
		navBackground.setStroke(
		(int) (1 * getResources()
		.getDisplayMetrics().density + 0.5f),
		android.graphics.Color.rgb(243, 220, 232)
		);
		
		bottomNav.setBackground(navBackground);
		bottomNav.setPadding(
		(int) (4 * getResources().getDisplayMetrics().density + 0.5f),
		0,
		(int) (4 * getResources().getDisplayMetrics().density + 0.5f),
		0
		);
		
		bottomNav.setGravity(android.view.Gravity.CENTER);
		bottomNav.setElevation(
		12 * getResources().getDisplayMetrics().density
		);
		bottomNav.setTranslationZ(
		6 * getResources().getDisplayMetrics().density
		);
		
		// Add it above the scrolling dashboard
		frame.addView(bottomNav);
		bottomNav.bringToFront();
		
		// Keep dashboard content visible above the bottom navigation
		scroll.setClipToPadding(false);
		
		scroll.setPadding(
		scroll.getPaddingLeft(),
		scroll.getPaddingTop(),
		scroll.getPaddingRight(),
		(int) (110 * getResources()
		.getDisplayMetrics().density + 0.5f)
		);
		textview27.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ooo.ttf"), 1);
		textview24.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ooo.ttf"), 1);
		txtCycleDay.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ooo.ttf"), 1);
		linear33.setBackgroundResource(R.drawable.octagram_outline);
		view1.setBackgroundResource(R.drawable.bg_bottom_navigation);
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (adview1 != null) {
			adview1.destroy();
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (adview1 != null) {
			adview1.pause();
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (adview1 != null) {
			adview1.resume();
		}
	}
	public void _showMyBottomSheet() {
		
		// 1. إنشاء كائن من الكلاس الذي عرفناه في JavaManager
		CustomSheetFragment sheet = new CustomSheetFragment();
		
		// 2. عرضه باستخدام Fragment Manager
		sheet.show(getSupportFragmentManager(), "MyCustomSheetTag");
	}
	
	
	public void _extra() {
	}
	private void firebaseAuthWithGoogle(String idToken) {
		AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
		auth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
			
			@Override
			public void onComplete(@NonNull Task<AuthResult> task) {
				if (task.isSuccessful()) {
					user = auth.getCurrentUser();
					sp.edit().putString("username", user.getDisplayName()).commit();
					sp.edit().putString("profile", user.getPhotoUrl().toString()).commit();
					if (task.getResult().getAdditionalUserInfo().isNewUser()) SketchwareUtil.showMessage(getApplicationContext(), "Welcome 🤗 New User"); else SketchwareUtil.showMessage(getApplicationContext(), "Welcome back ");
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Failed to sign in");
				}
			}
		});
	}
	//[END auth_with_google]
	{
	}
	
}