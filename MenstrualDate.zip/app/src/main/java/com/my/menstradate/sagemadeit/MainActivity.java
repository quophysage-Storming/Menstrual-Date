package com.my.menstradate.sagemadeit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.pm.ActivityInfo;


public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String fontName = "";
	private String typeace = "";
	private double click = 0;
	private double startX = 0;
	private double endX = 0;
	private boolean firstClick = false;
	private double currentPage = 0;
	final View[] dots = new View[3];
	final int[] currentIndex = {0};
	final long[] lastClickTime = {0};
	private LinearLayout mainLayout;
	long lastGeneralClickTime = 0L;
	Handler mainHandler;
	boolean isLongClick = false;
	public Handler handler;
	public Runnable runnable;
	
	private LinearLayout Background_intro_page;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private ImageView img;
	private LinearLayout Background_text;
	private LinearLayout Background_transition_level;
	private LinearLayout Background_button;
	private LinearLayout linear5;
	private TextView Text_title;
	private TextView Text_info;
	private LinearLayout dot3;
	private LinearLayout linear2;
	private LinearLayout dot2;
	private LinearLayout linear3;
	private LinearLayout dot1;
	private LinearLayout next_button;
	private LinearLayout back_button;
	private TextView Text_next;
	private ImageView img_next;
	private TextView textview3;
	
	private TimerTask timer;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		// It is causing a noticeable decrease in performance! We recommend you do this in the Application instead here if you know how.
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Background_intro_page = findViewById(R.id.Background_intro_page);
		linear4 = findViewById(R.id.linear4);
		linear6 = findViewById(R.id.linear6);
		img = findViewById(R.id.img);
		Background_text = findViewById(R.id.Background_text);
		Background_transition_level = findViewById(R.id.Background_transition_level);
		Background_button = findViewById(R.id.Background_button);
		linear5 = findViewById(R.id.linear5);
		Text_title = findViewById(R.id.Text_title);
		Text_info = findViewById(R.id.Text_info);
		dot3 = findViewById(R.id.dot3);
		linear2 = findViewById(R.id.linear2);
		dot2 = findViewById(R.id.dot2);
		linear3 = findViewById(R.id.linear3);
		dot1 = findViewById(R.id.dot1);
		next_button = findViewById(R.id.next_button);
		back_button = findViewById(R.id.back_button);
		Text_next = findViewById(R.id.Text_next);
		img_next = findViewById(R.id.img_next);
		textview3 = findViewById(R.id.textview3);
	}
	
	private void initializeLogic() {
		_changeActivityFont("ooo");
		_rippleRoundStroke(next_button, "#ED4975", "#000000", 100, 0, "#000000");
		_rippleRoundStroke(back_button, "#FCE4EC", "#000000", 100, 0, "#40A8F6");
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.setStatusBarColor(Color.parseColor("#FFFFFF"));
			window.setNavigationBarColor(Color.parseColor("#00000000"));
			int flags = window.getDecorView().getSystemUiVisibility();
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
			}
			flags |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
			flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
			window.getDecorView().setSystemUiVisibility(flags);
		}
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		// Configure the next icon only; skip and language icons were removed.
		Drawable drawableNext = getResources().getDrawable(R.drawable.next);
		int sizeInDp = 18;
		float scale = getResources().getDisplayMetrics().density;
		int sizeInPx = (int) (sizeInDp * scale + 0.5f);
		img_next.setImageDrawable(drawableNext);
		img_next.getLayoutParams().width = sizeInPx;
		img_next.getLayoutParams().height = sizeInPx;
		img_next.requestLayout();
		img_next.setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
		
		/*
 * Required global variables:
 *
 * long lastGeneralClickTime = 0L;
 * Handler handler;
 * Runnable runnable;
 * boolean isLongClick = false;
 *
 * Existing global variables:
 * View[] dots = new View[3];
 * int[] currentIndex = {0};
 * ImageView img, img_next;
 * TextView Text_title, Text_info, Text_next;
 * View next_button, back_button, mainLayout;
 */
		
		// 1. Keep the Activity in portrait orientation.
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
		// 2. Check whether onboarding has already been completed.
		android.content.SharedPreferences onboardingPrefs =
		getSharedPreferences("app_preferences", MODE_PRIVATE);
		
		if (onboardingPrefs.getBoolean("onboarding_completed", false)) {
			Intent intent = new Intent(MainActivity.this, SecondActivity.class);
			startActivity(intent);
			finish();
			return;
		}
		
		// 3. Initialize the main-thread Handler.
		handler = new Handler(Looper.getMainLooper());
		
		// Prevent multiple rapid clicks.
		lastGeneralClickTime = 0L;
		
		// Initialize the views.
		dots[0] = findViewById(R.id.dot1);
		dots[1] = findViewById(R.id.dot2);
		dots[2] = findViewById(R.id.dot3);
		
		img = findViewById(R.id.img);
		img_next = findViewById(R.id.img_next);
		
		Text_title = findViewById(R.id.Text_title);
		Text_info = findViewById(R.id.Text_info);
		Text_next = findViewById(R.id.Text_next);
		
		next_button = findViewById(R.id.next_button);
		back_button = findViewById(R.id.back_button);
		
		mainLayout = findViewById(R.id.Background_intro_page);
		
		// 4. Display complete images without cropping.
		img.setScaleType(ImageView.ScaleType.FIT_CENTER);
		img_next.setScaleType(ImageView.ScaleType.FIT_CENTER);
		
		// 5. Enable justified text on supported Android versions.
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			Text_info.setJustificationMode(
			android.text.Layout.JUSTIFICATION_MODE_INTER_WORD
			);
		}
		
		// 6. Disable long-press behavior on navigation buttons.
		_blockLongPress(next_button);
		_blockLongPress(back_button);
		
		// 7. Define onboarding images and text.
		final int[] images = {
			R.drawable.elcomecuate,
			R.drawable.arningafiki,
			R.drawable.esearchapercuate
		};
		
		final String[] titles = {
			"Track Your Menstrual Cycle!",
			"Be Prepared Every Day!",
			"A Healthier You Starts Here!"
		};
		
		final String[] infos = {
			"Know your cycle, predict your period, understand your body, and take control of your health - all in one place.",
			"Get period reminders, track your flow, manage symptoms and always be ready - no surprises.",
			"Feel confident, supported, and in sync with your body. Your cycle, your rules."
		};
		
		// 8. Configure the indicator dots.
		for (int i = 0; i < dots.length; i++) {
			GradientDrawable gd = new GradientDrawable();
			gd.setShape(GradientDrawable.RECTANGLE);
			
			gd.setColor(
			i == 0
			? Color.parseColor("#40A8F6")
			: Color.parseColor("#E5F5F5")
			);
			
			gd.setCornerRadius(
			3 * getResources().getDisplayMetrics().density / 2f
			);
			
			dots[i].setBackground(gd);
			
			android.view.ViewGroup.LayoutParams params =
			dots[i].getLayoutParams();
			
			if (params != null) {
				params.width = (int) (
				(i == 0 ? 35 : 20)
				* getResources().getDisplayMetrics().density
				);
				
				params.height = (int) (
				3 * getResources().getDisplayMetrics().density
				);
				
				dots[i].setLayoutParams(params);
			}
		}
		
		// 9. Display the first onboarding page.
		currentIndex[0] = 0;
		
		img.setImageResource(images[0]);
		Text_title.setText(titles[0]);
		Text_info.setText(infos[0]);
		
		back_button.setVisibility(View.GONE);
		
		// Initialize the button label and visibility.
		_setButtonState();
		
		// 10. Define automatic navigation.
		// Automatic navigation must never complete onboarding.
		runnable = new Runnable() {
			@Override
			public void run() {
				if (isFinishing() || isDestroyed()) {
					return;
				}
				
				if (currentIndex[0] < dots.length - 1) {
					next_button.performClick();
					
					if (currentIndex[0] < dots.length - 1) {
						handler.postDelayed(this, 4000);
					}
				}
			}
		};
		
		handler.postDelayed(runnable, 4000);
		
		// 11. Back button: navigate to the previous onboarding page.
		back_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				long clickTime = System.currentTimeMillis();
				
				if (clickTime - lastGeneralClickTime < 500) {
					return;
				}
				
				lastGeneralClickTime = clickTime;
				
				if (currentIndex[0] <= 0) {
					return;
				}
				
				handler.removeCallbacks(runnable);
				
				final int oldIndex = currentIndex[0];
				final int finalIndex = oldIndex - 1;
				
				_animateDotChange(dots[oldIndex], dots[finalIndex]);
				
				final int imageDuration = 300;
				final int textDuration = 200;
				
				img.animate().cancel();
				Text_title.animate().cancel();
				Text_info.animate().cancel();
				
				img.animate()
				.translationX(img.getWidth())
				.alpha(0f)
				.setDuration(imageDuration)
				.start();
				
				Text_title.animate()
				.translationX(Text_title.getWidth())
				.alpha(0f)
				.setDuration(textDuration)
				.start();
				
				Text_info.animate()
				.translationX(Text_info.getWidth())
				.alpha(0f)
				.setDuration(textDuration)
				.withEndAction(new Runnable() {
					@Override
					public void run() {
						if (isFinishing() || isDestroyed()) {
							return;
						}
						
						img.setScaleType(ImageView.ScaleType.FIT_CENTER);
						img.setImageResource(images[finalIndex]);
						
						Text_title.setText(titles[finalIndex]);
						Text_info.setText(infos[finalIndex]);
						
						img.setTranslationX(-img.getWidth());
						Text_title.setTranslationX(-Text_title.getWidth());
						Text_info.setTranslationX(-Text_info.getWidth());
						
						img.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(imageDuration)
						.start();
						
						Text_title.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(textDuration)
						.start();
						
						Text_info.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(textDuration)
						.start();
						
						_updateButtonState(finalIndex);
					}
				})
				.start();
				
				currentIndex[0] = finalIndex;
				
				if (currentIndex[0] < dots.length - 1) {
					handler.postDelayed(runnable, 4000);
				}
			}
		});
		
		// 12. Next and Get Started use the same button.
		next_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				long clickTime = System.currentTimeMillis();
				
				if (clickTime - lastGeneralClickTime < 500) {
					return;
				}
				
				lastGeneralClickTime = clickTime;
				
				// Open the destination only when Get Started is pressed.
				if (currentIndex[0] == dots.length - 1) {
					handler.removeCallbacks(runnable);
					
					getSharedPreferences("app_preferences", MODE_PRIVATE)
					.edit()
					.putBoolean("onboarding_completed", true)
					.apply();
					
					Intent intent = new Intent(
					MainActivity.this,
					SecondActivity.class
					);
					
					startActivity(intent);
					
					overridePendingTransition(
					android.R.anim.slide_in_left,
					android.R.anim.fade_out
					);
					
					finish();
					return;
				}
				
				handler.removeCallbacks(runnable);
				
				final int oldIndex = currentIndex[0];
				final int finalIndex = oldIndex + 1;
				
				_animateDotChange(dots[oldIndex], dots[finalIndex]);
				
				final int imageDuration = 300;
				final int textDuration = 200;
				
				img.animate().cancel();
				Text_title.animate().cancel();
				Text_info.animate().cancel();
				
				img.animate()
				.translationX(-img.getWidth())
				.alpha(0f)
				.setDuration(imageDuration)
				.start();
				
				Text_title.animate()
				.translationX(-Text_title.getWidth())
				.alpha(0f)
				.setDuration(textDuration)
				.start();
				
				Text_info.animate()
				.translationX(-Text_info.getWidth())
				.alpha(0f)
				.setDuration(textDuration)
				.withEndAction(new Runnable() {
					@Override
					public void run() {
						if (isFinishing() || isDestroyed()) {
							return;
						}
						
						img.setScaleType(ImageView.ScaleType.FIT_CENTER);
						img.setImageResource(images[finalIndex]);
						
						Text_title.setText(titles[finalIndex]);
						Text_info.setText(infos[finalIndex]);
						
						img.setTranslationX(img.getWidth());
						Text_title.setTranslationX(Text_title.getWidth());
						Text_info.setTranslationX(Text_info.getWidth());
						
						img.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(imageDuration)
						.start();
						
						Text_title.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(textDuration)
						.start();
						
						Text_info.animate()
						.translationX(0)
						.alpha(1f)
						.setDuration(textDuration)
						.start();
						
						_updateButtonState(finalIndex);
					}
				})
				.start();
				
				currentIndex[0] = finalIndex;
				
				if (currentIndex[0] == 1) {
					_showButtons();
				}
				
				if (currentIndex[0] < dots.length - 1) {
					handler.postDelayed(runnable, 4000);
				}
			}
		});
		// =======================================================
		// ** التعديل النهائي والمركز للتحكم في وقت "القفز" **
		// =======================================================
		
		final LinearLayout parentLayout = findViewById(R.id.Background_intro_page);
		android.animation.LayoutTransition layoutTransition = new android.animation.LayoutTransition();
		parentLayout.setLayoutTransition(layoutTransition);
		
		// 1. تحديد مدة التحريك بالمللي ثانية (مثلاً 300 مللي ثانية)
		long movementDurationMs = 300L; 
		
		// 2. إبقاء إصلاح "اهتزاز النص" فعالاً (إلغاء التحريك CHANGING العام)
		// هذا يمنع التضارب ويحل مشكلة الـ Jitter
		layoutTransition.setAnimator(android.animation.LayoutTransition.CHANGING, null); 
		layoutTransition.disableTransitionType(android.animation.LayoutTransition.CHANGING); 
		
		// 3. إلغاء التحريك التلقائي لظهور واختفاء العنصر نفسه (لتجنب التلاشي وغيره)
		// نستخدم "null" لضمان عدم وجود تحريك، مما يلبي طلب "بدون تلاشي بدون اي شي"
		layoutTransition.setAnimator(android.animation.LayoutTransition.APPEARING, null);
		layoutTransition.setAnimator(android.animation.LayoutTransition.DISAPPEARING, null);
		
		// 4. التحكم في وقت "القفز السلس" فقط (حركة العناصر المحيطة)
		// هذا يعيد تفعيل التحريك السلس الافتراضي ويتحكم في وقته.
		
		// تحريك العناصر المحيطة عند ظهور عنصر جديد
		layoutTransition.setDuration(android.animation.LayoutTransition.CHANGE_APPEARING, movementDurationMs);
		
		// تحريك العناصر المحيطة عند اختفاء عنصر
		layoutTransition.setDuration(android.animation.LayoutTransition.CHANGE_DISAPPEARING, movementDurationMs);
		
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (handler != null) {
			handler.removeCallbacksAndMessages(null);
		}
	}
	
	@Override
	public void onBackPressed() {
		
		if (handler != null && runnable != null) {
			handler.removeCallbacks(runnable);
		}
		
		finish();
	}
	public void _UI_Ripple(final View _view, final String _bg, final double _lt, final double _rt, final double _lb, final double _rb, final double _str, final String _str_color, final double _ele, final String _ripple) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_bg));
		gd.setStroke((int)_str, Color.parseColor(_str_color));
		gd.setCornerRadii(new float[] {(float)_lt, (float)_lt, (float)_rt, (float)_rt, (float)_rb, (float)_rb, (float)_lb, (float)_lb});
		_view.setElevation((int)_ele);
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_ripple)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
		_view.setBackground(ripdrb);
	}
	
	
	public void _Animator(final View _view, final String _propertyName, final double _value, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_propertyName);
		anim.setFloatValues((float)_value);
		anim.setDuration((long)_duration);
		anim.start();
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			} else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				} else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					} else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float) _round);
		GG.setStroke((int) _stroke, Color.parseColor("#" + _strokeclr.replace("#", "")));
		_view.setElevation(0f);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(
		new android.content.res.ColorStateList(
		new int[][]{ new int[]{} }, 
		new int[]{ Color.parseColor("#22000000") }
		), 
		GG,  
		null 
		);
		_view.setBackground(RE);
	}
	
	
	public void _animateDotChange(final View _currentDot, final View _nextDot) {
		// مدخلين: _currentDot و _nextDot
		
		GradientDrawable currentBg = (GradientDrawable) _currentDot.getBackground();
		GradientDrawable nextBg = (GradientDrawable) _nextDot.getBackground();
		
		// تغيير لون الخط الحالي إلى غير نشط
		currentBg.setColor(Color.parseColor("#F5F5F5"));
		
		// تغيير لون الخط التالي إلى نشط
		nextBg.setColor(Color.parseColor("#40A8F6"));
		
		// قيم البيكسل
		final int dpWidthNormal = (int) (20 * getResources().getDisplayMetrics().density);
		final int dpWidthActive = (int) (35 * getResources().getDisplayMetrics().density); // وسط بين 30 و40
		
		// انميشن تكبير العرض للخط النشط
		ValueAnimator animator = ValueAnimator.ofInt(dpWidthNormal, dpWidthActive);
		animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
			@Override
			public void onAnimationUpdate(ValueAnimator valueAnimator) {
				_nextDot.getLayoutParams().width = (int) valueAnimator.getAnimatedValue();
				_nextDot.requestLayout();
			}
		});
		animator.setDuration(250);
		animator.setInterpolator(new android.view.animation.OvershootInterpolator());
		animator.start();
		
		// ارجاع الخط السابق لحجمه الطبيعي
		_currentDot.getLayoutParams().width = dpWidthNormal;
		_currentDot.requestLayout();
	}
	
	
	public void _showButtons() {
		// ---------------------------------------------
		// إظهار الأزرار بالأنيميشن
		// --------------------------------------------
		// إظهار back_button بصعود سلس
		back_button.setVisibility(View.VISIBLE);
		back_button.setTranslationY(200); // يبدأ أسفل مكانه
		back_button.animate()
		.translationY(0)           // يصل لمكانه الطبيعي
		.setDuration(300)          // أبطأ من next_button
		.start();
		
		// إظهار next_button بصعود أسرع
		next_button.setVisibility(View.VISIBLE);
		next_button.setTranslationY(200); // يبدأ أسفل مكانه
		next_button.animate()
		.translationY(0)           // يصل لمكانه الطبيعي
		.setDuration(200)          // أسرع من back_button
		.start();
		
		
		// ---------------------------------------------
		// إخفاء الأزرار بالأنيميشن
		//
	}
	
	
	public void _hideButtons() {
		
		// إخفاء back_button بالهبوط أسرع
		back_button.animate()
		.translationY(200)         // ينزل أسفل الشاشة
		.setDuration(200)          // أسرع من next_button
		.withEndAction(new Runnable() {
			@Override
			public void run() {
				back_button.setVisibility(View.GONE);
			}
		}).start();
		
		// إخفاء next_button بالهبوط أبطأ
		next_button.animate()
		.translationY(200)         // ينزل أسفل الشاشة
		.setDuration(300)          // أبطأ من back_button
		.withEndAction(new Runnable() {
			@Override
			public void run() {
				next_button.setVisibility(View.GONE);
			}
		}).start();
	}
	
	
	public void _blockLongPress(final View _view) {
		// 9. منع الضغط المطول (Block Long Press)
		_view.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				isLongClick = true; // ضبط حالة الضغط المطول
				return true; // إرجاع true يستهلك الحدث ويمنع الاستجابة الافتراضية
			}
		});
	}
	
	
	public void _setButtonState() {
		// هذا هو الكود الصحيح لدالة _setButtonState() التي لا تستقبل مداخل
		
		// نستخدم المتغير العام currentIndex[0] للوصول إلى الفهرس
		if (currentIndex[0] == dots.length - 1) { 
			// الشريحة الأخيرة: إظهار "أبدأ الآن"
			Text_next.setText("Get Started!");
			handler.removeCallbacks(runnable);
			back_button.setVisibility(View.VISIBLE);
			
		} else if (currentIndex[0] == 0) { 
			// الشريحة الأولى: إظهار "التالي" وإخفاء زر الرجوع
			Text_next.setText("Next");
			img_next.setVisibility(View.VISIBLE);
			back_button.setVisibility(View.GONE);
		} else {
			// الشرائح الوسطى: إظهار "التالي" وكلا السهمين
			Text_next.setText("Next");
			back_button.setVisibility(View.VISIBLE);
			
		}
	}
	
	
	public void _updateButtonState(final double _index) {
		// هذا هو الكود النهائي للدالة _updateButtonState() (بدون مدخلات)
		
		// 1. تحديد الحالة الحالية والسابقة للنص (لتقرير ما إذا كان يجب تشغيل الأنيميشن)
		final boolean isFinalState = (currentIndex[0] == dots.length - 1);
		final boolean wasFinalState = (Text_next.getText().toString().equals("Get Started!"));
		
		// 2. تحديد ما إذا كنا نعود من الشريحة الأخيرة (لتطبيق الحركة المعكوسة)
		final boolean isReturning = (wasFinalState && !isFinalState);
		
		// 3. الشرط: الأنيميشن يحدث فقط إذا كانت حالة "أبدأ الآن!" تتغير (من/إلى).
		if (isFinalState != wasFinalState) { 
			
			final long ANIM_DURATION = 100; 
			
			// 👈 تحديد اتجاه الانزلاق (Slide)
			// إذا كنا عائدين: الإخفاء للأسفل (Hide Down) والظهور من الأعلى (Show from Top)
			// إذا كنا نتقدم: الإخفاء للأعلى (Hide Up) والظهور من الأسفل (Show from Bottom)
			final float hideTranslation = isReturning ? Text_next.getHeight() : -Text_next.getHeight();
			final float showTranslation = isReturning ? -Text_next.getHeight() : Text_next.getHeight();
			
			// أ. إخفاء النص والصورة بالانزلاق والتلاشي (Slide & Fade Out)
			Text_next.animate()
			.translationY(hideTranslation)
			.alpha(0f)
			.setDuration(ANIM_DURATION)
			.start(); 
			
			img_next.animate()
			.translationY(hideTranslation)
			.alpha(0f)
			.setDuration(ANIM_DURATION)
			.withEndAction(new Runnable() {
				@Override
				public void run() {
					// ب. تحديث المحتوى (النص والصورة)
					_setButtonState(); 
					
					// 🚨 تغيير الأيقونة
					if (isFinalState) {
						img_next.setImageResource(R.drawable.img); 
					} else {
						img_next.setImageResource(R.drawable.next); 
					}
					
					// ج. تهيئة النص والصورة الجديدين للموقع المعاكس
					Text_next.setTranslationY(showTranslation);
					img_next.setTranslationY(showTranslation); 
					
					// د. إظهار النص الجديد والصورة بالانزلاق والعودة للموقع الأصلي (Slide & Fade In)
					Text_next.animate()
					.translationY(0)
					.alpha(1f)
					.setDuration(ANIM_DURATION)
					.start();
					
					img_next.animate() 
					.translationY(0)
					.alpha(1f)
					.setDuration(ANIM_DURATION)
					.start();
				}
			}).start();
			
		} else {
			// 👈 إذا كنا نتحرك بين الشرائح الوسطى، نكتفي بالتحديث المباشر
			_setButtonState(); 
			
			// إعادة ضبط الأنماط لضمان الظهور الصحيح
			Text_next.setAlpha(1.0f); 
			Text_next.setTranslationY(0); 
			img_next.setAlpha(1.0f); 
			img_next.setTranslationY(0); 
		}
	}
	
}