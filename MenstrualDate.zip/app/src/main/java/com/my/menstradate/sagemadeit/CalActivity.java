package com.my.menstradate.sagemadeit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.button.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class CalActivity extends AppCompatActivity {
	
	private LinearLayout linear20;
	private LinearLayout linear21;
	private TextView textview7;
	private TextView textview8;
	private TextView textview13;
	private TextInputLayout textinputlayout1;
	private TextView textview14;
	private TextInputLayout textinputlayout2;
	private TextView textview15;
	private TextInputLayout textinputlayout3;
	private MaterialButton btn_calculate;
	private TextView textview16;
	private TextInputEditText edittext1;
	private TextInputEditText edittext2;
	private TextInputEditText edittext3;
	private TextView textview17;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		EdgeToEdge.enable(this);
		setContentView(R.layout.cal);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		// It is causing a noticeable decrease in performance! We recommend you do this in the Application instead here if you know how.
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		textview7 = findViewById(R.id.textview7);
		textview8 = findViewById(R.id.textview8);
		textview13 = findViewById(R.id.textview13);
		textinputlayout1 = findViewById(R.id.textinputlayout1);
		textview14 = findViewById(R.id.textview14);
		textinputlayout2 = findViewById(R.id.textinputlayout2);
		textview15 = findViewById(R.id.textview15);
		textinputlayout3 = findViewById(R.id.textinputlayout3);
		btn_calculate = findViewById(R.id.btn_calculate);
		textview16 = findViewById(R.id.textview16);
		edittext1 = findViewById(R.id.edittext1);
		edittext2 = findViewById(R.id.edittext2);
		edittext3 = findViewById(R.id.edittext3);
		textview17 = findViewById(R.id.textview17);
		
		btn_calculate.setOnClickListener(_v -> {
			try {
				String firstDayText = edittext1.getText().toString().trim();
				String periodText = edittext2.getText().toString().trim();
				String cycleText = edittext3.getText().toString().trim();
				
				if (firstDayText.isEmpty() || periodText.isEmpty() || cycleText.isEmpty()) {
					Toast.makeText(getApplicationContext(),
					"Please fill in all fields",
					Toast.LENGTH_SHORT).show();
					return;
				}
				
				// Parse the selected start date.
				java.text.SimpleDateFormat[] formats = {
					new java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US),
					new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US),
					new java.text.SimpleDateFormat("MM/dd/yyyy", java.util.Locale.US),
					new java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.US),
					new java.text.SimpleDateFormat("MM-dd-yyyy", java.util.Locale.US),
					new java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.US)
				};
				
				java.util.Date parsedDate = null;
				
				for (java.text.SimpleDateFormat format : formats) {
					format.setLenient(false);
					try {
						parsedDate = format.parse(firstDayText);
						if (parsedDate != null) {
							break;
						}
					} catch (java.text.ParseException e) {
						// Try the next supported date format.
					}
				}
				
				if (parsedDate == null) {
					Toast.makeText(getApplicationContext(),
					"Please select a valid period start date",
					Toast.LENGTH_LONG).show();
					return;
				}
				
				int periodLength = Integer.parseInt(periodText);
				int cycleLength = Integer.parseInt(cycleText);
				
				if (periodLength < 1 || periodLength > 10) {
					Toast.makeText(getApplicationContext(),
					"Period duration must be between 1 and 10 days",
					Toast.LENGTH_LONG).show();
					return;
				}
				
				if (cycleLength < 21 || cycleLength > 45) {
					Toast.makeText(getApplicationContext(),
					"Cycle length must be between 21 and 45 days",
					Toast.LENGTH_LONG).show();
					return;
				}
				
				java.util.Calendar firstDay = java.util.Calendar.getInstance();
				firstDay.setTime(parsedDate);
				firstDay.set(java.util.Calendar.HOUR_OF_DAY, 12);
				firstDay.set(java.util.Calendar.MINUTE, 0);
				firstDay.set(java.util.Calendar.SECOND, 0);
				firstDay.set(java.util.Calendar.MILLISECOND, 0);
				
				java.util.Calendar today = java.util.Calendar.getInstance();
				today.set(java.util.Calendar.HOUR_OF_DAY, 0);
				today.set(java.util.Calendar.MINUTE, 0);
				today.set(java.util.Calendar.SECOND, 0);
				today.set(java.util.Calendar.MILLISECOND, 0);
				
				if (firstDay.getTimeInMillis() > today.getTimeInMillis()) {
					Toast.makeText(getApplicationContext(),
					"The last period start date cannot be in the future",
					Toast.LENGTH_LONG).show();
					return;
				}
				
				// Reference logic:
				// M = cycleLength - 28
				// P_days = periodLength - 1
				// ovulation offset = 12 + M = cycleLength - 16
				
				int periodDaysToAdd = periodLength - 1;
				int ovulationOffset = cycleLength - 16;
				
				java.text.SimpleDateFormat outputFormat =
				new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault());
				
				StringBuilder results = new StringBuilder();
				java.util.Calendar periodStart = (java.util.Calendar) firstDay.clone();
				
				results.append("YOUR CYCLE PREDICTIONS\n");
				results.append("Estimated dates for the next 6 cycles\n\n");
				
				for (int i = 0; i < 6; i++) {
					java.util.Calendar periodEnd = (java.util.Calendar) periodStart.clone();
					periodEnd.add(java.util.Calendar.DAY_OF_MONTH, periodDaysToAdd);
					
					java.util.Calendar ovulationStart = (java.util.Calendar) periodStart.clone();
					ovulationStart.add(java.util.Calendar.DAY_OF_MONTH, ovulationOffset);
					
					java.util.Calendar ovulationEnd = (java.util.Calendar) ovulationStart.clone();
					ovulationEnd.add(java.util.Calendar.DAY_OF_MONTH, 4);
					
					results.append("CYCLE ").append(i + 1).append("\n");
					results.append("Period starts: ")
					.append(outputFormat.format(periodStart.getTime())).append("\n");
					results.append("Period ends: ")
					.append(outputFormat.format(periodEnd.getTime())).append("\n");
					results.append("Estimated ovulation window: ")
					.append(outputFormat.format(ovulationStart.getTime()))
					.append(" - ")
					.append(outputFormat.format(ovulationEnd.getTime()))
					.append("\n\n");
					
					// Advance from the full date, preserving the correct year.
					periodStart.add(java.util.Calendar.DAY_OF_MONTH, cycleLength);
				}
				
				results.append("Note: These dates are estimates, not guarantees. ");
				results.append("Ovulation and cycle timing can vary.");
				
				textview17.setText(results.toString());
				
			} catch (NumberFormatException e) {
				Toast.makeText(getApplicationContext(),
				"Enter valid numbers for period and cycle length",
				Toast.LENGTH_LONG).show();
			} catch (Exception e) {
				Toast.makeText(getApplicationContext(),
				"Unable to calculate. Please check your entries.",
				Toast.LENGTH_LONG).show();
			}
			
		});
		
		edittext1.setOnClickListener(_v -> {
			java.util.Calendar calendar = java.util.Calendar.getInstance();
			
			java.util.Date currentDate = new java.util.Date();
			calendar.setTime(currentDate);
			
			int year = calendar.get(java.util.Calendar.YEAR);
			int month = calendar.get(java.util.Calendar.MONTH);
			int day = calendar.get(java.util.Calendar.DAY_OF_MONTH);
			
			android.app.DatePickerDialog datePicker =
			new android.app.DatePickerDialog(
			YourActivity.this,
			new android.app.DatePickerDialog.OnDateSetListener() {
				@Override
				public void onDateSet(
				android.widget.DatePicker view,
				int selectedYear,
				int selectedMonth,
				int selectedDay
				) {
					java.util.Calendar selectedDate =
					java.util.Calendar.getInstance();
					
					selectedDate.set(
					selectedYear,
					selectedMonth,
					selectedDay,
					12, 0, 0
					);
					selectedDate.set(
					java.util.Calendar.MILLISECOND, 0
					);
					
					java.text.SimpleDateFormat sdf =
					new java.text.SimpleDateFormat(
					"dd/MM/yyyy",
					java.util.Locale.US
					);
					
					edittext1.setText(
					sdf.format(selectedDate.getTime())
					);
				}
			},
			year,
			month,
			day
			);
			
			datePicker.getDatePicker().setMaxDate(
			System.currentTimeMillis()
			);
			
			datePicker.setTitle("Select your last period start date");
			datePicker.show();
		});
	}
	
	private void initializeLogic() {
	}
	
}